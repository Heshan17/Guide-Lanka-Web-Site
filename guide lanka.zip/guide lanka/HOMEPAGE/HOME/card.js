// Enable smooth horizontal scrolling with the mouse wheel
document.querySelectorAll('.scroll-container').forEach((container) => {
    container.addEventListener('wheel', (event) => {
        if (event.deltaY !== 0) {
            event.preventDefault();
            container.scrollBy({
                left: event.deltaY > 0 ? 250 : -250,
                behavior: 'smooth',
            });
        }
    });
});
